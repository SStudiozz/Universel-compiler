import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart' show ChangeNotifierProvider;

import '../attachments/data/attachment_store.dart';
import '../attachments/domain/attachment.dart';
import 'domain/tool_spec.dart';

/// Android Storage Access Framework bridge. All paths are relative to the
/// persisted tree URI; no raw filesystem path is exposed to the model.
class ProjectFolderService extends ChangeNotifier {
  /// Action requests against the selected project should not be left to a
  /// model's optional tool choice. This deliberately excludes how-to questions
  /// so asking how to manage files does not trigger a filesystem operation.
  static bool requiresToolForRequest(String input) {
    final text = input.trim();
    final howTo = RegExp(
      r'\bhow\s+(?:do|can)\s+i\b|\bhow\s+to\b|\bshow\s+me\s+how\b|\bexplain\s+how\b',
      caseSensitive: false,
    );
    if (text.isEmpty || howTo.hasMatch(text)) return false;
    final mentionsProject = RegExp(
      r'\b(project|selected folder|project folder|workspace|repository|repo)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final action = RegExp(
      r'\b(list|show|check|inspect|browse|find|search|read|open|view|create|make|write|save|edit|modify|update|rename|move|duplicate|copy|attach|download|send|delete|remove)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final fileTarget = RegExp(
      r'\b(files?|folders?|directories|source|code|contents?|project|repository|repo)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final filePath = RegExp(
      r'\b[\w./-]+\.(?:txt|md|dart|py|js|ts|json|ya?ml|toml|rs|cpp|h|java|kt|xml|html|css|gradle|sh|ps1)\b',
      caseSensitive: false,
    ).hasMatch(text);
    final toolCheck = RegExp(
          r'\b(check|inspect|test|verify|list|show)\b',
          caseSensitive: false,
        ).hasMatch(text) &&
        RegExp(r'\b(tools?|functions?|mcp)\b', caseSensitive: false)
            .hasMatch(text) &&
        !RegExp(r'\b(examples?|syntax|instructions)\b', caseSensitive: false)
            .hasMatch(text);
    return toolCheck || (action && (mentionsProject || fileTarget || filePath));
  }

  static const _channel = MethodChannel('ondevice_llm/project_folder');
  Map<String, String>? _folder;
  bool _loading = false;
  Future<void>? _loadFuture;
  Map<String, String>? get folder => _folder;
  bool get isSelected => _folder != null;
  bool get loading => _loading;

  Future<void> load() {
    final pending = _loadFuture;
    if (pending != null) return pending;
    _loading = true;
    final future = _loadInternal();
    _loadFuture = future;
    return future;
  }

  Future<void> _loadInternal() async {
    try {
      final value = await _channel.invokeMapMethod<String, dynamic>('currentFolder');
      _folder = value == null ? null : {'uri': '${value['uri']}', 'name': '${value['name']}'};
    } catch (_) {
      _folder = null;
    } finally {
      _loading = false;
      _loadFuture = null;
      notifyListeners();
    }
  }

  Future<void> selectFolder() async {
    final value = await _channel.invokeMapMethod<String, dynamic>('pickFolder');
    if (value != null) {
      _folder = {'uri': '${value['uri']}', 'name': '${value['name']}'};
      notifyListeners();
    }
  }

  Future<void> clearFolder() async {
    await _channel.invokeMethod<bool>('clearFolder');
    _folder = null;
    notifyListeners();
  }

  // Client-side validation improves error messages. The Android SAF bridge
  // repeats these checks and is the authoritative security boundary.
  List<String> _segments(String path, {bool allowRoot = false}) {
    if (path.isEmpty && allowRoot) return const [];
    if (path.isEmpty || path.startsWith('/') || path.startsWith('\\') ||
        RegExp(r'^[A-Za-z]:').hasMatch(path) || path.contains('\\') ||
        path.contains('://') || path.contains('\u0000')) {
      throw const FormatException('Only project-relative paths are allowed.');
    }
    final parts = path.split('/');
    if (parts.any((part) => part.isEmpty || part == '.' || part == '..' ||
        part.runes.any((rune) => rune < 32 || rune == 127))) {
      throw const FormatException('Invalid project-relative path.');
    }
    return parts;
  }

  String _safeName(String name) {
    if (name.trim().isEmpty || name == '.' || name == '..' ||
        name.contains('/') || name.contains('\\') || name.contains('\u0000') ||
        name.runes.any((rune) => rune < 32 || rune == 127)) {
      throw const FormatException('Invalid project item name.');
    }
    return name;
  }

  Future<List<Map<String, dynamic>>> list(String path) async {
    _segments(path, allowRoot: true);
    return (await _channel.invokeListMethod<dynamic>('list', {'path': path}) ?? [])
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList(growable: false);
  }

  Future<String> read(String path) async {
    _segments(path);
    return await _channel.invokeMethod<String>('read', {'path': path}) ?? '';
  }

  Future<Attachment> attachFile(
    String path, {
    required String expectedUri,
  }) async {
    _segments(path);
    if (_folder?['uri'] != expectedUri) {
      throw StateError('The selected project folder changed during this task.');
    }
    final exported = await _channel.invokeMapMethod<String, dynamic>(
      'export',
      {'path': path},
    );
    final sourcePath = exported?['path'] as String?;
    final name = exported?['name'] as String?;
    if (sourcePath == null || name == null || name.isEmpty) {
      throw StateError('The project file could not be exported.');
    }
    try {
      return await AttachmentStore.import(
        name: name,
        sourcePath: sourcePath,
        deferProcessing: true,
      );
    } finally {
      try {
        await File(sourcePath).delete();
      } catch (_) {}
    }
  }

  Future<void> write(String path, String content) async {
    _segments(path);
    await _channel.invokeMethod<bool>('write', {'path': path, 'content': content});
  }

  /// Runtime-owned persistent agent memory. These methods intentionally bypass
  /// model-facing tool dispatch; the agent cannot claim to author verified state.
  Future<void> ensureMemoryDirectory() async {
    if (!isSelected) throw StateError('No project folder selected.');
    await _channel.invokeMethod<bool>('mkdir', {'path': '.ai_memory'});
  }

  Future<String?> readMemoryFile(String name) async {
    if (!const {'memory.txt', 'agent_context.txt', 'task_state.txt', 'project_knowledge.txt', 'recovery.txt'}.contains(name)) {
      throw ArgumentError.value(name, 'name', 'Unknown memory file.');
    }
    if (!isSelected) throw StateError('No project folder selected.');
    try {
      return await _channel.invokeMethod<String>('read', {'path': '.ai_memory/$name'});
    } on PlatformException catch (error) {
      if ((error.message ?? '').toLowerCase().contains('missing') ||
          (error.message ?? '').toLowerCase().contains('not a file') ||
          (error.message ?? '').toLowerCase().contains('not found')) return null;
      rethrow;
    }
  }

  Future<void> writeMemoryFile(String name, String content) async {
    if (!const {'memory.txt', 'agent_context.txt', 'task_state.txt', 'project_knowledge.txt', 'recovery.txt'}.contains(name)) {
      throw ArgumentError.value(name, 'name', 'Unknown memory file.');
    }
    if (!isSelected) throw StateError('No project folder selected.');
    await ensureMemoryDirectory();
    await _channel.invokeMethod<bool>('write', {
      'path': '.ai_memory/$name', 'content': content,
    });
  }

  Future<void> _recordVerifiedOperation(String operation, String output) async {
    try {
      final previous = await readMemoryFile('task_state.txt') ?? '';
      final compact = output.replaceAll('\n', ' ');
      final excerpt = compact.substring(0, compact.length.clamp(0, 700).toInt());
      final line = 'Verified operation: $operation -> $excerpt';
      final lines = previous
          .split('\n')
          .where((entry) => entry.startsWith('Verified operation:'))
          .toList();
      lines.add(line);
      final retained = lines.length > 30 ? lines.sublist(lines.length - 30) : lines;
      final header = previous
          .split('\n')
          .where((entry) => !entry.startsWith('Verified operation:'))
          .join('\n')
          .trimRight();
      await writeMemoryFile('task_state.txt', '$header\n\n${retained.join('\n')}');
      await writeMemoryFile(
        'recovery.txt',
        'Last verified operation: $operation\nResult: $excerpt\n\nTask checkpoint:\n$header',
      );
    } catch (_) {
      // Memory is a checkpoint aid, not a reason to fail an already verified operation.
    }
  }

  Future<void> mkdir(String path) async {
    _segments(path);
    await _channel.invokeMethod<bool>('mkdir', {'path': path});
  }

  Future<void> rename(String path, String name) async {
    _segments(path);
    _safeName(name);
    await _channel.invokeMethod<bool>('rename', {'path': path, 'name': name});
  }

  Future<void> move(String sourcePath, String destinationPath) async {
    _segments(sourcePath);
    _segments(destinationPath);
    await _channel.invokeMethod<bool>('move', {
      'sourcePath': sourcePath,
      'destinationPath': destinationPath,
    });
  }

  Future<void> duplicate(String sourcePath, String destinationPath) async {
    _segments(sourcePath);
    _segments(destinationPath);
    await _channel.invokeMethod<bool>('duplicate', {
      'sourcePath': sourcePath,
      'destinationPath': destinationPath,
    });
  }

  Future<Map<String, dynamic>> metadata(String path) async {
    final parts = _segments(path);
    final parent = parts.length == 1 ? '' : parts.take(parts.length - 1).join('/');
    final entries = await list(parent);
    final matches = entries.where((item) => item['name'] == parts.last).toList();
    if (matches.isEmpty) throw StateError('Project item not found: $path');
    return matches.first;
  }

  Future<List<Map<String, String>>> searchContents(
    String query, {String path = ''}
  ) async {
    final needle = query.trim().toLowerCase();
    if (needle.isEmpty || needle.length > 120) {
      throw FormatException('Search query must contain 1 to 120 characters.');
    }
    _segments(path, allowRoot: true);
    if (path == '.ai_memory' || path.startsWith('.ai_memory/')) {
      throw StateError('.ai_memory is reserved for application-managed state.');
    }
    final results = <Map<String, String>>[];
    var inspected = 0;
    Future<void> visit(String directory, int depth) async {
      if (depth > 12 || inspected >= 500 || results.length >= 30) return;
      final entries = await list(directory);
      for (final entry in entries) {
        if (inspected >= 500 || results.length >= 30) break;
        final name = '${entry['name'] ?? ''}';
        final relative = [directory, name].where((part) => part.isNotEmpty).join('/');
        if (relative == '.ai_memory' || relative.startsWith('.ai_memory/')) continue;
        if (entry['directory'] == true) {
          await visit(relative, depth + 1);
          continue;
        }
        inspected++;
        final size = (entry['size'] as num?)?.toInt() ?? 0;
        if (size > 1000000 || size < 0) continue;
        try {
          final content = await read(relative);
          final index = content.toLowerCase().indexOf(needle);
          if (index >= 0) {
            final start = (index - 100).clamp(0, content.length).toInt();
            final end = (index + needle.length + 180).clamp(0, content.length).toInt();
            results.add({'path': relative, 'excerpt': content.substring(start, end)});
          }
        } catch (_) {
          // Binary, unreadable and provider-error files are skipped safely.
        }
      }
    }
    await visit(path, 0);
    return results;
  }

  Future<void> delete(String path) async {
    _segments(path);
    await _channel.invokeMethod<bool>('delete', {'path': path});
  }

  List<ToolSpec> get specs => !isSelected ? const [] : const [
    ToolSpec(
      name: 'project_list_files',
      description: 'List files and folders ONLY inside the currently selected project folder. Use strict relative paths; use an empty path for the project root. Access outside this folder is blocked.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_read_file',
      description: 'Read a UTF-8 text file ONLY inside the selected project folder. Absolute paths and parent traversal are rejected. Maximum 1 MB.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_write_file',
      description: 'Create or overwrite a UTF-8 text file ONLY inside the selected project folder. Absolute paths and parent traversal are rejected. Parent folders are created inside the project only. Maximum 1 MB per file.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}, 'content': {'type': 'string'}}, 'required': ['path', 'content']},
    ),
    ToolSpec(
      name: 'project_create_folder',
      description: 'Create a folder ONLY inside the selected project folder. Absolute paths and parent traversal are rejected.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_rename',
      description: 'Rename a file or folder ONLY inside the selected project folder. Supply its strict relative path and a new basename. The project root cannot be renamed.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}, 'name': {'type': 'string'}}, 'required': ['path', 'name']},
    ),
    ToolSpec(
      name: 'project_move',
      description: 'Move a file or folder ONLY within the selected project folder. The destination is a strict relative path including the new item name. Parent folders are created inside the project only. Do not move a folder into itself or a descendant. The destination must not already exist.',
      parameters: {'type': 'object', 'properties': {'source_path': {'type': 'string'}, 'destination_path': {'type': 'string'}}, 'required': ['source_path', 'destination_path']},
    ),
    ToolSpec(
      name: 'project_duplicate',
      description: 'Duplicate a file or folder ONLY inside the selected project folder. Supply strict relative source_path and destination_path. The destination must not already exist; folder contents are copied recursively.',
      parameters: {'type': 'object', 'properties': {'source_path': {'type': 'string'}, 'destination_path': {'type': 'string'}}, 'required': ['source_path', 'destination_path']},
    ),
    ToolSpec(
      name: 'project_search_contents',
      description: 'Search UTF-8 text contents inside the selected project folder. Bounded to 500 files, 1 MB per file, depth 12, and 30 matches. Optional path scopes the search.',
      parameters: {'type': 'object', 'properties': {'query': {'type': 'string'}, 'path': {'type': 'string'}}, 'required': ['query']},
    ),
    ToolSpec(
      name: 'project_get_metadata',
      description: 'Get the selected project item metadata: relative path, name, file/folder type and size. Use a strict project-relative path.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_attach_file',
      description: 'Attach a file from the selected project folder to your reply as a downloadable chat attachment. Use only when the user explicitly asks you to provide or attach that file. The file is copied into app-private attachment storage; the project original is not changed. Maximum 64 MB.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
    ToolSpec(
      name: 'project_delete',
      description: 'Permanently delete a file or folder and all its contents ONLY inside the selected project folder. Absolute paths and parent traversal are rejected. This is destructive and cannot be undone. Never use on the project root; inspect the target path first and delete only when the user explicitly asks or the task clearly requires removing that exact item.',
      parameters: {'type': 'object', 'properties': {'path': {'type': 'string'}}, 'required': ['path']},
    ),
  ];

  Future<ToolResult> call(ToolCall call, {required String expectedUri}) async {
    final watch = Stopwatch()..start();
    try {
      if (_folder?['uri'] != expectedUri) {
        throw StateError('The selected project folder changed during this task.');
      }
      final args = call.args;
      final protected = <String>[
        if (args['path'] is String) args['path'] as String,
        if (args['source_path'] is String) args['source_path'] as String,
        if (args['destination_path'] is String) args['destination_path'] as String,
      ];
      if (protected.any((p) => p == '.ai_memory' || p.startsWith('.ai_memory/') ||
          p == 'project_root/.ai_memory' || p.startsWith('project_root/.ai_memory/'))) {
        throw StateError('.ai_memory is reserved for verified application-managed state.');
      }
      String argString(String key) {
        final value = args[key];
        if (value is! String || value.trim().isEmpty) throw FormatException('Missing $key.');
        return value;
      }
      // Not every tool uses `path`: move has source_path/destination_path.
      // Empty is valid only for listing the project root; native handlers
      // reject it for file operations and for project-root deletion.
      final pathValue = args['path'];
      var path = pathValue is String ? pathValue : '';
      // Small models sometimes call the selected folder root "project_root"
      // even though the schema explicitly documents an empty relative path.
      // Resolve that conventional root label without weakening path checks.
      if (call.name == 'project_list_files' &&
          const {'project_root', '.', '/'}.contains(path.trim())) {
        path = '';
      } else if (path.startsWith('project_root/')) {
        path = path.substring('project_root/'.length);
      }
      String output;
      switch (call.name) {
        case 'project_list_files':
          final entries = await list(path);
          output = const JsonEncoder.withIndent('  ').convert(entries);
          if (path.isEmpty) {
            await writeMemoryFile(
              'project_knowledge.txt',
              'Latest observed project-root listing:\n${output.substring(0, output.length.clamp(0, 12000).toInt())}',
            );
          }
          break;
        case 'project_read_file':
          output = await read(path);
          break;
        case 'project_write_file':
          final content = args['content'];
          if (content is! String) throw const FormatException('Missing content.');
          await write(path, content);
          output = 'Saved $path';
          break;
        case 'project_create_folder':
          await mkdir(path);
          output = 'Created folder $path';
          break;
        case 'project_rename':
          await rename(path, argString('name'));
          output = 'Renamed $path';
          break;
        case 'project_move':
          final source = argString('source_path');
          final destination = argString('destination_path');
          await move(source, destination);
          output = 'Moved $source to $destination';
          break;
        case 'project_duplicate':
          final source = argString('source_path');
          final destination = argString('destination_path');
          await duplicate(source, destination);
          output = 'Duplicated $source to $destination';
          break;
        case 'project_search_contents':
          final query = argString('query');
          final scope = args['path'] is String ? args['path'] as String : '';
          final matches = await searchContents(query, path: scope);
          output = const JsonEncoder.withIndent('  ').convert(matches);
          break;
        case 'project_get_metadata':
          final details = await metadata(path);
          output = const JsonEncoder.withIndent('  ').convert(details);
          break;
        case 'project_attach_file':
          final attachment = await attachFile(path, expectedUri: expectedUri);
          await _recordVerifiedOperation(
            call.name,
            'Attached ${attachment.name} (${attachment.sizeBytes} bytes) to the assistant reply.',
          );
          return ToolResult(
            call: call,
            output: 'Attached ${attachment.name} (${attachment.sizeBytes} bytes) to the assistant reply.',
            ok: true,
            elapsedMs: watch.elapsedMilliseconds,
            attachments: [attachment],
          );
        case 'project_delete':
          await delete(path);
          output = 'Deleted $path';
          break;
        default:
          throw StateError('Unknown project tool ${call.name}.');
      }
      await _recordVerifiedOperation(call.name, output);
      return ToolResult(call: call, output: output, ok: true, elapsedMs: watch.elapsedMilliseconds);
    } catch (e) {
      return ToolResult(call: call, output: 'Project folder error: $e', ok: false, elapsedMs: watch.elapsedMilliseconds);
    }
  }
}

final projectFolderProvider = ChangeNotifierProvider<ProjectFolderService>((ref) {
  final service = ProjectFolderService();
  service.load();
  return service;
});
