# Android project workspace and MCP

## Project folder access

On Android, open **Settings > Tools & Integrations > Project folder**. The app uses `ACTION_OPEN_DOCUMENT_TREE` and persists the selected SAF read/write permission. The agent receives relative-path tools only while a folder is selected:

- `project_list_files`
- `project_read_file`
- `project_write_file`
- `project_create_folder`
- `project_rename`
- `project_move` (destination is a new full relative path, including the item name)
- `project_attach_file` (copies a requested project file into a downloadable assistant attachment; 64 MB limit)
- `project_delete` (recursively deletes the selected file/folder; project root is never deletable)

Operations are routed through `DocumentFile` under the exact persisted SAF tree URI chosen by the user. The native bridge verifies that the read/write grant still exists before every operation. Only strict relative paths are accepted: absolute paths, drive-qualified paths, URI strings, backslashes, empty path segments, control characters, `.` and `..` are rejected. The project root itself cannot be renamed, moved, written as a file, or deleted. Moves use the document provider's native move operation when available and fall back to streaming copy-then-delete; if source deletion fails after a successful copy, both locations are retained and the tool reports that state. Moves into a folder's own descendant and overwriting an existing destination are rejected. Delete recursively removes the exact selected item and its children. Text reads and writes are capped at 1 MB per file; directory listings are capped at 2,000 entries. Binary files are not decoded as text. The user can disconnect the folder from the Project folder page.

The global **Settings > Tools & Integrations > Let the model call tools** switch must be enabled. Before each Android chat turn, the app restores the persisted folder permission and includes the selected-folder tools in the model's tool list. Local models with native tool-call support receive the function schemas; local models without it receive the text-tool protocol instructions and examples. The system prompt explicitly tells the model that these tools access the real selected folder and to inspect files before editing. The app checks that the folder selection has not changed before executing a tool call. While a project folder is connected, MCP tools are deliberately withheld from the model: an MCP server may have independent filesystem permissions, so exposing it would invalidate the folder-only guarantee. Disconnect the project folder before using MCP tools.

Android's document provider controls which locations can be selected. Some protected roots (including parts of `Android/data`) may not be selectable or writable on modern Android versions.

## MCP on Android

Open **Settings > Tools & Integrations > MCP servers**. The Android setup is one endpoint field, an optional bearer API key, and one **Connect** action: the app derives a server label from the host, performs the MCP initialize handshake, discovers tools, and reports connection errors instead of silently saving an untested endpoint. Android supports Streamable HTTP endpoints using HTTPS for remote servers and HTTP only for loopback (`localhost`, `127.0.0.1`, `::1`). Redirects are not followed. Stdio MCP servers remain unsupported on Android because this app does not launch arbitrary child processes there. OAuth and arbitrary custom headers are not supported; the optional bearer token is stored in secure storage and sent only as an Authorization header.

The user can enable/disable servers and individual tools. A tool must be explicitly marked **Always allow this tool** before the agent can call it on Android; unapproved calls are denied. Approvals are invalidated when the server configuration changes. The page shows a bounded in-memory recent activity log.

## Execution isolation

No arbitrary shell or generated-code execution was added. This build does not claim to provide a code-execution sandbox. MCP servers are external services and should be connected only when trusted. They are not exposed to the agent while project-folder isolation is active.

## Validation

Run `flutter analyze`, the full Flutter test suite, and an Android debug build on a machine with the matching Flutter 3.44+ and Android SDK/NDK toolchain. Device testing is required for SAF provider behavior and real MCP endpoint compatibility.
